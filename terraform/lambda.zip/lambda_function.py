#!/usr/bin/env python

import sys, traceback, json

def main():
    return {'key1': "value", 'key2': "value2"}

if __name__ == "__main__":

    sys.stderr = sys.stdout

    try:
        data = main()
        print("Content-Type: application/json; charset=UTF-8\n")
        print(json.dumps((data), indent=3))

    except Exception as e:
        print("Status: 500\nContent-Type: text/plain; charset=UTF-8\n")
        traceback.print_exc(file=sys.stdout)


# AWS Lambda Entry Point
def lambda_handler(event, context):

    http_request = {
        'host': event['headers']['host'],
        'path': event['path'],
        'headers': {},
        'query_string': event['queryStringParameters']
    }

    try:
        data = main()

    except Exception as e:
         return  {'statusCode': 500, 'headers': {'Content-Type': "text/plain"}, 'body': format(e)}

    return {'statusCode': 200, 'body': json.dumps(data)}
